import React from 'react';

function StudentDetails({ studentName, course, section }) {
  return (
    <div>
      <h2>Student Details</h2>
      <p>Name: {studentName}</p>
      <p>Course: {course}</p>
      <p>Section: {section}</p>
    </div>
  );
}

export default StudentDetails;