import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef([]);

  const handleButtonClick = () => {
    const emptyInput = inputRefs.current.find(input => input.value.trim() === '');
    if (emptyInput) {
      emptyInput.focus();
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input ref={(input) => (inputRefs.current[0] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input ref={(input) => (inputRefs.current[1] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input ref={(input) => (inputRefs.current[2] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input ref={(input) => (inputRefs.current[3] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input ref={(input) => (inputRefs.current[4] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input ref={(input) => (inputRefs.current[5] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input ref={(input) => (inputRefs.current[6] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input ref={(input) => (inputRefs.current[7] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input ref={(input) => (inputRefs.current[8] = input)} type='text' />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input ref={(input) => (inputRefs.current[9] = input)} type='text' />
      </div>
      <button type='button' onClick={handleButtonClick}>I'm a button</button>
    </>
  );
}

export default Problem3;